import SignUpForm from "../Components/SignUpForm";

const SignUpPage = () => {
  return (
    <>
      <h2>Register here</h2>
      <SignUpForm />
    </>
  );
};
export default SignUpPage;
