import SignInForm from "../Components/SignInForm";

const SignInPage = () => {
  return (
    <>
      <h2>Login here</h2>
      <SignInForm />
    </>
  );
};
export default SignInPage;
