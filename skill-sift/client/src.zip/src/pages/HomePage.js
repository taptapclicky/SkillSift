const HomePage = () => {
    return <>
    Welcome to homepage
    </>;
  };
  export default HomePage;
  